export const LIST_MUNDOS = 'LIST_MUNDOS';
export const ADD_MUNDOS = 'ADD_MUNDOS';