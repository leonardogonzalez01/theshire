import React from 'react';

const Logo = (props) => {
    return (
        <div>
            soy el logo
        </div>
    );
};

export default Logo;