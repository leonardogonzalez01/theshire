import React from 'react';

const Admin = () => {
    return (
        <div>
            soy el admin
        </div>
    );
};

export default Admin;