import React from 'react';

const Header = () => {
    return (
        <div>
            soy el header
        </div>
    );
};

export default Header;