import React from 'react';

const Nav = (props) => {
    return (
        <div>
            soy el nav
        </div>
    );
};

export default Nav;