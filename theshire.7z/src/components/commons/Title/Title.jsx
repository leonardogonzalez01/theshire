import React from 'react';

const Title = (props) => {
    return (
        <div>
            soy el title
        </div>
    );
};

export default Title;