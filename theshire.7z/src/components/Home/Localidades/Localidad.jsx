import React from 'react';

const Localidad = (props) => {
    return (
        <div>
            Localidad
        </div>
    );
};

export default Localidad;