import React from 'react';

const Footer = (props) => {
    return (
        <div>
            soy el footer
        </div>
    );
};

export default Footer;