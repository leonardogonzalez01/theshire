export const LIST_HEROES = 'LIST_HEROES';
export const ADD_HEROES = 'ADD_HEROES';